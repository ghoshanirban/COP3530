package midterm; // do not delete

public class TestStudentLL {

	public static void main(String[] args) {
		StudentDLL batch2023 = new StudentDLL();

		batch2023.insertFirst(19812,"Eric",3.18);
		batch2023.insertFirst(19813,"Tina",2.97);
		batch2023.insertLast(19221,"Alex",3.01);

		System.out.println(batch2023);

		batch2023.reverse();

		System.out.println(batch2023);

		batch2023.sortBasedOnGpa();

		System.out.println(batch2023);

		batch2023.insertFirst(19220,"June",3.78);

		System.out.println( batch2023.getkth( 3 ) );

		batch2023.insertAt(2, 89112, "Noah", 2.99);

		System.out.println( batch2023.traverseRight2Left() );

		batch2023.removeStudentHavingNNumber(19221);

		System.out.println(batch2023);

	}
}
