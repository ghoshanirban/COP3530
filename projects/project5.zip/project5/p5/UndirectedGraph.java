package p5; // do not delete

import graph.Graph;

public class UndirectedGraph {
	Graph G; // Initialize this from within the constructor; the graph must be undirected
	// Do not declare any other graph class inside this class. 

	//Scans in data for an undirected graph from file
	public UndirectedGraph(String inputFile) { }

	//Returns a string representation of graph
	public String toString() {
		return null; // dummy statement
	}

	//Counts number of "triangles" present in graph
	public int countTriplets() {
		return -1; // dummy statement
	}

	//Returns Breadth First Traversal from initial vertex 0
	//If any vertex is left unvisited (is not a connected graph) returns null
	public String ifConnectedThenBreadthFirstTraversal() {
		return null; // dummy statement
	}

	//Returns the path resulting in the lowest weight between two vertices
	public int findShortestPathLengthBetween(int u, int v) {
		return -1; // dummy statement
	}

	//Checks if current graph is a Tree
	public boolean isTree() {
		return false; // dummy statement

	}
}