package p3; // Do not delete this

import stacksandqueues.*; // Do not delete this

public class ExitFinder {

	// Complete this method; reads a maze from a file
	public ExitFinder(String mazeInputFile)  {

	}

	// Complete this method. The main stack algorithm must be implemented inside this method
	public void findExitPathStackBased() {
		// You must 'LinkedStack' from the 'stacksandqueues' package
		// complete the remaining part

	}

	// Complete this method; sends the solution to an output file named 'mazeSolution'
	public void sendSolutionTo(String mazeSolution)  {

	}


}
