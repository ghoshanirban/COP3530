package finalcoding;

public class TestStudentBinaryTree {
    public static void main(String[] args){
        // Create a few trees by hand and try out the methods; no need to use files;
        // just use the insert() method to create trees
        // See the slides and the binary tree HW for sample trees
    }
}
